package com.invesco.hapi.testing.login.steps;


import com.invesco.hapi.testing.config.ConfigFileReader;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.DriverManagerType;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class LoginStepDefintion {

    private WebDriver driver;
    private ConfigFileReader configFileReader;


    @Given("^user is already on Login Page$")
    public void user_already_on_login_page() {
        configFileReader = new ConfigFileReader();
        WebDriverManager.getInstance(DriverManagerType.CHROME).setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(configFileReader.getImplicitlyWait(), TimeUnit.SECONDS);
        driver.get();
    }

    @When("^user Navigate to Login Page$")
    public void user_Navigate_to_login_page() {

        //

        //Reg Exp:

        ////1. \"([^\"]*)\"

        ////2. \"(.*)\"

    }

    @And("^user enters \"(.*)\" and \"(.*)\"$")
    public void User_enters_username_and_password(String username, String password) {
        driver.findElement(By.name("email")).sendKeys(username);
        driver.findElement(By.name("password")).sendKeys(password);
    }

    @Then("^user clicks on login button$")
    public void user_clicks_on_login_button() {
        WebElement signinBtn =
                driver.findElement(By.xpath("//button[@type='submit']"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", signinBtn);
    }
}
