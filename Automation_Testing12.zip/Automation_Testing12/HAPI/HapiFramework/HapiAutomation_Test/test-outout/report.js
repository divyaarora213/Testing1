$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/features/login.feature");
formatter.feature({
  "line": 1,
  "name": "Login Action",
  "description": "",
  "id": "login-action",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 3,
  "name": "Successfuly login with Credentials",
  "description": "",
  "id": "login-action;successfuly-login-with-credentials",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 4,
  "name": "user is already on Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "user Navigate to Login Page",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "user enters \"\u003cusername\u003e\" and \"\u003cpassword\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "user clicks on login button",
  "keyword": "Then "
});
formatter.examples({
  "line": 8,
  "name": "",
  "description": "",
  "id": "login-action;successfuly-login-with-credentials;",
  "rows": [
    {
      "cells": [
        "username",
        "password"
      ],
      "line": 9,
      "id": "login-action;successfuly-login-with-credentials;;1"
    },
    {
      "cells": [
        "admin@hapi.com",
        "is1blesa"
      ],
      "line": 10,
      "id": "login-action;successfuly-login-with-credentials;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 10,
  "name": "Successfuly login with Credentials",
  "description": "",
  "id": "login-action;successfuly-login-with-credentials;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 4,
  "name": "user is already on Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "user Navigate to Login Page",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "user enters \"admin@hapi.com\" and \"is1blesa\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "user clicks on login button",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginStepDefintion.user_already_on_login_page()"
});
formatter.result({
  "duration": 7097745000,
  "status": "passed"
});
formatter.match({
  "location": "LoginStepDefintion.user_Navigate_to_login_page()"
});
formatter.result({
  "duration": 37100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "admin@hapi.com",
      "offset": 13
    },
    {
      "val": "is1blesa",
      "offset": 34
    }
  ],
  "location": "LoginStepDefintion.User_enters_username_and_password(String,String)"
});
formatter.result({
  "duration": 449241900,
  "status": "passed"
});
formatter.match({
  "location": "LoginStepDefintion.user_clicks_on_login_button()"
});
formatter.result({
  "duration": 3644263600,
  "status": "passed"
});
});